(function () {
  "use strict";

  // KEYWORDS is defined in keywords.js, loaded before this script.

  const TEST_MODE = false;          // set to true for a fast 10s/5s test cycle
  const WORK_MS = TEST_MODE ? 10 * 1000 : 15 * 60 * 1000;
  const BLANK_MS = TEST_MODE ? 5 * 1000 : 60 * 1000;

  const api = typeof browser !== "undefined" ? browser : chrome;
  const host = location.hostname.toLowerCase();

  async function isBlockedHost() {
    let customSites = [];
    let removedSites = [];
    try {
      const stored = await api.storage.local.get(["customSites", "removedSites"]);
      customSites = stored.customSites || [];
      removedSites = stored.removedSites || [];
    } catch (e) {
      // storage unavailable; fall back to built-in list only
    }
    if (removedSites.some((r) => host.includes(r))) return false;
    if (KEYWORDS.some((k) => host.includes(k))) return true;
    if (customSites.some((c) => host.includes(c))) return true;
    return false;
  }

  let blankTimeoutId = null;
  let workTimeoutId = null;
  let pauseInterval = null;
  let overlay = null;
  let blocker = null;
  let blanking = false;
  let wasHidden = false;

  const BLOCK_EVENTS = [
    "keydown", "keyup", "keypress", "mousedown", "mouseup", "click",
    "wheel", "contextmenu", "touchstart", "touchmove"
  ];

  const forceRepause = (e) => { if (blanking) e.target.pause(); };

  function clearTimers() {
    if (blankTimeoutId) clearTimeout(blankTimeoutId);
    if (workTimeoutId) clearTimeout(workTimeoutId);
    if (pauseInterval) clearInterval(pauseInterval);
    blankTimeoutId = workTimeoutId = pauseInterval = null;
  }

  // Starts (or restarts) the whole 1-min-blank / 15-min-work cycle from
  // scratch, blanking immediately.
  function startCycle() {
    clearTimers();
    if (overlay) hideOverlay();
    blanking = false;
    startBlank();
  }

  function startBlank() {
    blanking = true;
    console.log("[Focus Blank Break] BLANK starting for", BLANK_MS, "ms");
    showOverlay();
    pauseAllMedia();
    pauseInterval = setInterval(pauseAllMedia, 200);
    blankTimeoutId = setTimeout(endBlank, BLANK_MS);
  }

  function endBlank() {
    console.log("[Focus Blank Break] BLANK ending, work period starting");
    blanking = false;
    hideOverlay();
    if (pauseInterval) clearInterval(pauseInterval);
    pauseInterval = null;
    workTimeoutId = setTimeout(startBlank, WORK_MS);
  }

  function pauseAllMedia() {
    document.querySelectorAll("video, audio").forEach((el) => {
      if (!el.paused) el.pause();
      // Catch instant auto-resume attempts by the page during a blank.
      if (!el.dataset.__fbbBound) {
        el.addEventListener("play", forceRepause);
        el.dataset.__fbbBound = "1";
      }
    });
  }

  function showOverlay() {
    overlay = document.createElement("div");
    overlay.id = "__fbb_overlay__";
    Object.assign(overlay.style, {
      position: "fixed",
      top: "0", left: "0", right: "0", bottom: "0",
      width: "100vw", height: "100vh",
      background: "#000",
      zIndex: "2147483647",
      margin: "0", padding: "0",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    });
    overlay.tabIndex = -1;

    overlay.innerHTML = `
      <div style="
        color:#1a1a1a;
        font-family:-apple-system,Helvetica,Arial,sans-serif;
        font-size:22px;
        font-weight:600;
        text-align:center;
        max-width:80vw;
        letter-spacing:0.3px;
      ">What are we doing? What's going on?</div>
    `;

    (document.body || document.documentElement).appendChild(overlay);
    overlay.focus();

    document.documentElement.style.overflow = "hidden";

    blocker = function (e) {
      e.stopImmediatePropagation();
      e.preventDefault();
    };
    BLOCK_EVENTS.forEach((evt) => window.addEventListener(evt, blocker, true));
  }

  function hideOverlay() {
    if (overlay) {
      overlay.remove();
      overlay = null;
    }
    if (blocker) {
      BLOCK_EVENTS.forEach((evt) => window.removeEventListener(evt, blocker, true));
      blocker = null;
    }
    document.documentElement.style.overflow = "";
  }

  // Leaving the tab (switching away / minimizing) and coming back counts
  // as "re-entering the site" -> restart the cycle with an immediate blank.
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      wasHidden = true;
    } else if (wasHidden) {
      wasHidden = false;
      if (!running) return;
      console.log("[Focus Blank Break] tab revisited, resetting cycle");
      startCycle();
    }
  });

  let running = false;

  async function init() {
    const blocked = await isBlockedHost();
    if (!blocked) {
      console.log("[Focus Blank Break] no match for host:", host);
      return;
    }
    console.log("[Focus Blank Break] active on", host, "TEST_MODE:", TEST_MODE);
    running = true;
    startCycle();
  }

  // If the user adds/removes this site via the popup while the page is
  // already open, react immediately instead of waiting for a reload.
  api.storage.onChanged.addListener(async (changes, area) => {
    if (area !== "local") return;
    if (!("customSites" in changes) && !("removedSites" in changes)) return;
    const blocked = await isBlockedHost();
    if (blocked && !running) {
      running = true;
      console.log("[Focus Blank Break] site added, starting");
      startCycle();
    } else if (!blocked && running) {
      running = false;
      console.log("[Focus Blank Break] site removed, stopping");
      clearTimers();
      if (overlay) hideOverlay();
    }
  });

  if (document.body) {
    init();
  } else {
    document.addEventListener("DOMContentLoaded", init);
  }
})();

(function () {
  "use strict";

  const HOLD_MS = 45 * 1000; // how long you must hold to remove a site

  const api = typeof browser !== "undefined" ? browser : chrome;
  const hostEl = document.getElementById("host");
  const statusEl = document.getElementById("status");
  const controlsEl = document.getElementById("controls");
  const hintEl = document.getElementById("hint");

  let currentHost = null;

  async function isBlockedHost(host) {
    const stored = await api.storage.local.get(["customSites", "removedSites"]);
    const customSites = stored.customSites || [];
    const removedSites = stored.removedSites || [];
    if (removedSites.some((r) => host.includes(r))) return false;
    if (KEYWORDS.some((k) => host.includes(k))) return true;
    if (customSites.some((c) => host.includes(c))) return true;
    return false;
  }

  async function addSite(host) {
    const stored = await api.storage.local.get(["customSites", "removedSites"]);
    const customSites = stored.customSites || [];
    const removedSites = stored.removedSites || [];
    if (!customSites.includes(host)) customSites.push(host);
    const newRemoved = removedSites.filter((r) => r !== host);
    await api.storage.local.set({ customSites, removedSites: newRemoved });
  }

  async function removeSite(host) {
    const stored = await api.storage.local.get(["customSites", "removedSites"]);
    const removedSites = stored.removedSites || [];
    if (!removedSites.includes(host)) removedSites.push(host);
    await api.storage.local.set({ removedSites });
  }

  function renderBlocked(host) {
    statusEl.textContent = "Blocked on this site";
    statusEl.className = "status-blocked";
    controlsEl.innerHTML = `
      <button id="removeBtn">
        <div id="progressFill"></div>
        <span>Hold to remove (45s)</span>
      </button>
    `;
    hintEl.textContent = "Removal takes 45s of holding — release early and it resets.";

    const btn = document.getElementById("removeBtn");
    const fill = document.getElementById("progressFill");
    let holdStart = null;
    let rafId = null;

    function tick() {
      const elapsed = Date.now() - holdStart;
      const pct = Math.min(100, (elapsed / HOLD_MS) * 100);
      fill.style.width = pct + "%";
      if (elapsed >= HOLD_MS) {
        cancelHold();
        removeSite(host).then(() => {
          statusEl.textContent = "Removed — no longer blocked";
          statusEl.className = "status-free";
          renderFree(host);
        });
        return;
      }
      rafId = requestAnimationFrame(tick);
    }

    function startHold() {
      holdStart = Date.now();
      rafId = requestAnimationFrame(tick);
    }

    function cancelHold() {
      if (rafId) cancelAnimationFrame(rafId);
      rafId = null;
      holdStart = null;
      fill.style.width = "0%";
    }

    btn.addEventListener("mousedown", startHold);
    btn.addEventListener("touchstart", (e) => { e.preventDefault(); startHold(); });
    ["mouseup", "mouseleave", "touchend", "touchcancel"].forEach((evt) =>
      btn.addEventListener(evt, cancelHold)
    );
  }

  function renderFree(host) {
    statusEl.textContent = "Not blocked on this site";
    statusEl.className = "status-free";
    controlsEl.innerHTML = `<button id="addBtn">Add this site</button>`;
    hintEl.textContent = "";
    document.getElementById("addBtn").addEventListener("click", async () => {
      await addSite(host);
      statusEl.textContent = "Added — reload the page to apply";
      statusEl.className = "status-blocked";
      renderBlocked(host);
    });
  }

  async function init() {
    const tabs = await api.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0] || !tabs[0].url) {
      hostEl.textContent = "No active page";
      return;
    }
    let host;
    try {
      host = new URL(tabs[0].url).hostname.toLowerCase();
    } catch (e) {
      hostEl.textContent = "Not a website";
      return;
    }
    if (!host) {
      hostEl.textContent = "Not a website";
      return;
    }
    currentHost = host;
    hostEl.textContent = host;

    const blocked = await isBlockedHost(host);
    if (blocked) {
      renderBlocked(host);
    } else {
      renderFree(host);
    }
  }

  init();
})();

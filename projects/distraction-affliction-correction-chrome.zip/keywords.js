// Shared built-in list of distracting site keywords, used by both
// content.js and popup.js so they always agree on what's blocked.
const KEYWORDS = [
  "youtube.com", "youtu.be", "instagram.com", "netflix.com",
  "facebook.com", "fb.com", "twitter.com", "x.com", "tiktok.com",
  "reddit.com", "twitch.tv", "hulu.com", "amazon.com", "primevideo.com",
  "disneyplus.com", "hbomax.com", "max.com", "vimeo.com", "dailymotion.com",
  "pinterest.com", "snapchat.com", "bingeflix", "chillflix",
  "123movies", "fmovies", "putlocker", "yts.", "1337x", "thepiratebay",
  "rarbg", "soap2day", "gomovies", "solarmovie", "moviesjoy", "sflix",
  "vidcloud", "9anime", "kissanime", "gogoanime",
  // gaming
  "roblox.com", "steampowered.com", "epicgames.com", "itch.io",
  "poki.com", "crazygames.com", "addictinggames.com", "coolmathgames.com",
  "miniclip.com", "kongregate.com", "agar.io", "slither.io", "diep.io",
  "surviv.io", "krunker.io", "shellshock.io", "chess.com", "lichess.org",
  // email
  "gmail.com", "mail.google.com", "outlook.com", "outlook.live.com",
  "outlook.office.com", "outlook.office365.com",
  // messaging / texting
  "discord.com", "whatsapp.com", "web.whatsapp.com", "groupme.com",
  "web.groupme.com", "messages.google.com", "messenger.com",
  "slack.com", "telegram.org", "web.telegram.org", "signal.org", "skype.com"
];

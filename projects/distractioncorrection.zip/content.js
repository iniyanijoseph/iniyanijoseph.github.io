(function () {
  "use strict";

  // ---- Configure your distracting sites here (substrings matched against hostname) ----
  const KEYWORDS = [
    "youtube.com", "youtu.be", "instagram.com", "netflix.com",
    "facebook.com", "fb.com", "twitter.com", "x.com", "tiktok.com",
    "reddit.com", "twitch.tv", "hulu.com", "amazon.com", "primevideo.com",
    "disneyplus.com", "hbomax.com", "max.com", "vimeo.com", "dailymotion.com",
    "pinterest.com", "snapchat.com", "bingeflix", "chillflix",
    "123movies", "fmovies", "putlocker", "yts.", "1337x", "thepiratebay",
    "rarbg", "soap2day", "gomovies", "solarmovie", "moviesjoy", "sflix",
    "vidcloud", "9anime", "kissanime", "gogoanime"
  ];

  const TEST_MODE = false;          // set to true for a fast 10s/5s test cycle
  const WORK_MS = TEST_MODE ? 10 * 1000 : 15 * 60 * 1000;
  const BLANK_MS = TEST_MODE ? 5 * 1000 : 60 * 1000;

  const host = location.hostname.toLowerCase();
  const match = KEYWORDS.find((k) => host.includes(k));
  if (!match) {
    console.log("[Focus Blank Break] no match for host:", host);
    return;
  }
  console.log("[Focus Blank Break] active on", host, "matched:", match, "TEST_MODE:", TEST_MODE);

  let blankTimeoutId = null;
  let workTimeoutId = null;
  let pauseInterval = null;
  let overlay = null;
  let blocker = null;
  let blanking = false;
  let wasHidden = false;

  const BLOCK_EVENTS = [
    "keydown", "keyup", "keypress", "mousedown", "mouseup", "click",
    "wheel", "contextmenu", "touchstart", "touchmove"
  ];

  const forceRepause = (e) => { if (blanking) e.target.pause(); };

  function clearTimers() {
    if (blankTimeoutId) clearTimeout(blankTimeoutId);
    if (workTimeoutId) clearTimeout(workTimeoutId);
    if (pauseInterval) clearInterval(pauseInterval);
    blankTimeoutId = workTimeoutId = pauseInterval = null;
  }

  // Starts (or restarts) the whole 1-min-blank / 15-min-work cycle from
  // scratch, blanking immediately.
  function startCycle() {
    clearTimers();
    if (overlay) hideOverlay();
    blanking = false;
    startBlank();
  }

  function startBlank() {
    blanking = true;
    console.log("[Focus Blank Break] BLANK starting for", BLANK_MS, "ms");
    showOverlay();
    pauseAllMedia();
    pauseInterval = setInterval(pauseAllMedia, 200);
    blankTimeoutId = setTimeout(endBlank, BLANK_MS);
  }

  function endBlank() {
    console.log("[Focus Blank Break] BLANK ending, work period starting");
    blanking = false;
    hideOverlay();
    if (pauseInterval) clearInterval(pauseInterval);
    pauseInterval = null;
    workTimeoutId = setTimeout(startBlank, WORK_MS);
  }

  function pauseAllMedia() {
    document.querySelectorAll("video, audio").forEach((el) => {
      if (!el.paused) el.pause();
      // Catch instant auto-resume attempts by the page during a blank.
      if (!el.dataset.__fbbBound) {
        el.addEventListener("play", forceRepause);
        el.dataset.__fbbBound = "1";
      }
    });
  }

  function showOverlay() {
    overlay = document.createElement("div");
    overlay.id = "__fbb_overlay__";
    Object.assign(overlay.style, {
      position: "fixed",
      top: "0", left: "0", right: "0", bottom: "0",
      width: "100vw", height: "100vh",
      background: "#000",
      zIndex: "2147483647",
      margin: "0", padding: "0",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    });
    overlay.tabIndex = -1;

    overlay.innerHTML = `
      <div style="
        color:#1a1a1a;
        font-family:-apple-system,Helvetica,Arial,sans-serif;
        font-size:22px;
        font-weight:600;
        text-align:center;
        max-width:80vw;
        letter-spacing:0.3px;
      ">What are we doing? What's going on?</div>
    `;

    (document.body || document.documentElement).appendChild(overlay);
    overlay.focus();

    document.documentElement.style.overflow = "hidden";

    blocker = function (e) {
      e.stopImmediatePropagation();
      e.preventDefault();
    };
    BLOCK_EVENTS.forEach((evt) => window.addEventListener(evt, blocker, true));
  }

  function hideOverlay() {
    if (overlay) {
      overlay.remove();
      overlay = null;
    }
    if (blocker) {
      BLOCK_EVENTS.forEach((evt) => window.removeEventListener(evt, blocker, true));
      blocker = null;
    }
    document.documentElement.style.overflow = "";
  }

  // Leaving the tab (switching away / minimizing) and coming back counts
  // as "re-entering the site" -> restart the cycle with an immediate blank.
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      wasHidden = true;
    } else if (wasHidden) {
      wasHidden = false;
      console.log("[Focus Blank Break] tab revisited, resetting cycle");
      startCycle();
    }
  });

  function init() {
    startCycle();
  }

  if (document.body) {
    init();
  } else {
    document.addEventListener("DOMContentLoaded", init);
  }
})();

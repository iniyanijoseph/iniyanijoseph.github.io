#!/usr/bin/env python3
"""
Video Processing Script
Processes zip files containing 4K video files, normalizes them, and concatenates them.

Required dependencies:
pip install ffmpeg-python

Also requires FFmpeg to be installed on the system:
- Windows: Download from https://ffmpeg.org/download.html
- macOS: brew install ffmpeg
- Linux: sudo apt install ffmpeg (Ubuntu/Debian) or equivalent
"""

import os
import shutil
import zipfile
import glob
import subprocess
import tempfile
from pathlib import Path
import ffmpeg

# Configuration
SRC_DIR = "content/src"
UNZIPPED_DIR = "content/unzipped" 
OUTPUT_FILE = "content/inner.mp4"
START_DIR = "content/src/start"
END_DIR = "content/src/end"

# Video encoding settings - H.265 for smaller file sizes
VIDEO_CODEC = "libx265"  # H.265/HEVC codec
CRF_VALUE = 23  # Quality setting (18-28 recommended for H.265, lower = higher quality)
PRESET = "medium"  # Encoding speed preset (ultrafast, fast, medium, slow, slower)

# Video extensions to look for
VIDEO_EXTENSIONS = {'.mov', '.mp4', '.avi', '.mkv', '.wmv', '.flv', '.webm'}

def setup_directories():
    """Create necessary directories"""
    os.makedirs(UNZIPPED_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    print(f"Created directories: {UNZIPPED_DIR}, {os.path.dirname(OUTPUT_FILE)}")

def copy_all_files():
    """Copy all files (zip and video) from src to unzipped directory"""
    # Get all files in src directory (except start and end subdirectories)
    all_files = []
    for root, dirs, files in os.walk(SRC_DIR):
        # Skip start and end directories
        dirs[:] = [d for d in dirs if d not in ['start', 'end']]
        for file in files:
            all_files.append(os.path.join(root, file))
    
    if not all_files:
        print("No files found in src directory")
        return []
    
    copied_files = []
    for file_path in all_files:
        dest = os.path.join(UNZIPPED_DIR, os.path.basename(file_path))
        
        # Handle filename conflicts
        counter = 1
        original_dest = dest
        while os.path.exists(dest):
            name, ext = os.path.splitext(original_dest)
            dest = f"{name}_{counter}{ext}"
            counter += 1
        
        shutil.copy2(file_path, dest)
        copied_files.append(dest)
        print(f"Copied: {file_path} -> {dest}")
    
    return copied_files

def extract_nested_zips():
    """Extract all zip files recursively until no more zip files are found"""
    iteration = 0
    while True:
        iteration += 1
        print(f"Zip extraction iteration {iteration}")
        
        # Find all zip files in the unzipped directory
        zip_files = glob.glob(os.path.join(UNZIPPED_DIR, "*.zip"))
        
        if not zip_files:
            print(f"No more zip files found after {iteration-1} iterations")
            break
        
        print(f"Found {len(zip_files)} zip files to extract")
        
        # Extract all zip files
        extracted_any = False
        for zip_file in zip_files:
            try:
                with zipfile.ZipFile(zip_file, 'r') as zip_ref:
                    zip_ref.extractall(UNZIPPED_DIR)
                    print(f"Extracted: {zip_file}")
                    extracted_any = True
                # Remove the zip file after extraction
                os.remove(zip_file)
            except zipfile.BadZipFile:
                print(f"Error: {zip_file} is not a valid zip file")
                # Remove invalid zip file
                os.remove(zip_file)
            except Exception as e:
                print(f"Error extracting {zip_file}: {e}")
                # Remove problematic zip file to avoid infinite loop
                os.remove(zip_file)
        
        if not extracted_any:
            break
        
        # Flatten any newly extracted files to root level
        flatten_directory()

def flatten_directory():
    """Recursively move all files to the root of unzipped directory"""
    moved_files = []
    
    # Find all files recursively (not just video files at this stage)
    for root, dirs, files in os.walk(UNZIPPED_DIR):
        for file in files:
            file_path = os.path.join(root, file)
            
            # Skip files already in the root directory
            if os.path.dirname(file_path) != UNZIPPED_DIR:
                # Generate unique filename if conflict exists
                base_name = os.path.basename(file_path)
                dest_path = os.path.join(UNZIPPED_DIR, base_name)
                
                counter = 1
                original_dest = dest_path
                while os.path.exists(dest_path):
                    name, ext = os.path.splitext(base_name)
                    dest_path = os.path.join(UNZIPPED_DIR, f"{name}_{counter}{ext}")
                    counter += 1
                
                shutil.move(file_path, dest_path)
                moved_files.append(dest_path)
                print(f"Moved: {file_path} -> {dest_path}")
    
    # Remove empty directories
    for root, dirs, files in os.walk(UNZIPPED_DIR, topdown=False):
        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            try:
                if not os.listdir(dir_path):  # Directory is empty
                    os.rmdir(dir_path)
                    print(f"Removed empty directory: {dir_path}")
            except OSError:
                pass  # Directory not empty or other error
    
    return moved_files

def get_video_files():
    """Get all video files from the unzipped directory"""
    video_files = []
    for file in os.listdir(UNZIPPED_DIR):
        if Path(file).suffix.lower() in VIDEO_EXTENSIONS:
            video_files.append(os.path.join(UNZIPPED_DIR, file))
    
    # Sort for consistent ordering
    video_files.sort()
    return video_files

def get_video_info(video_path):
    """Get video information using ffprobe"""
    try:
        probe = ffmpeg.probe(video_path)
        video_stream = next((stream for stream in probe['streams'] if stream['codec_type'] == 'video'), None)
        return video_stream
    except ffmpeg.Error as e:
        print(f"Error probing {video_path}: {e}")
        return None

def normalize_and_encode_video(input_path, output_path):
    """Normalize video and encode to H.265 in one step"""
    try:
        # Target specs for normalization
        target_width = 3840
        target_height = 2160
        target_fps = 30
        
        (
            ffmpeg
            .input(input_path)
            .video.filter('scale', target_width, target_height)
            .output(output_path, 
                   vcodec=VIDEO_CODEC,
                   r=target_fps,
                   preset=PRESET,
                   crf=CRF_VALUE,
                   pix_fmt='yuv420p')
            .overwrite_output()
            .run(quiet=True)
        )
        print(f"Normalized and encoded: {input_path} -> {output_path}")
        return True
    except ffmpeg.Error as e:
        print(f"Error normalizing {input_path}: {e}")
        return False

def create_concat_file(video_files, concat_file_path):
    """Create a concat file for ffmpeg"""
    with open(concat_file_path, 'w') as f:
        for video_file in video_files:
            # Use absolute paths and escape special characters
            abs_path = os.path.abspath(video_file)
            # Escape single quotes in the path for ffmpeg
            escaped_path = abs_path.replace("'", r"\'")
            f.write(f"file '{escaped_path}'\n")

def concatenate_videos(video_files, output_path):
    """Concatenate multiple video files using copy (no re-encoding)"""
    if not video_files:
        print("No video files to concatenate")
        return False
    
    if len(video_files) == 1:
        # If only one file, just copy it
        shutil.copy2(video_files[0], output_path)
        print(f"Single file copied to: {output_path}")
        return True
    
    # Create temporary concat file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        concat_file = f.name
    
    try:
        create_concat_file(video_files, concat_file)
        
        # Use ffmpeg to concatenate without re-encoding
        (
            ffmpeg
            .input(concat_file, format='concat', safe=0)
            .output(output_path, c='copy')
            .overwrite_output()
            .run(quiet=True)
        )
        print(f"Concatenated {len(video_files)} files to: {output_path}")
        return True
        
    except ffmpeg.Error as e:
        print(f"Error concatenating videos: {e}")
        return False
    finally:
        # Clean up temp file
        if os.path.exists(concat_file):
            os.unlink(concat_file)

def find_video_in_directory(directory):
    """Find the first video file in a directory"""
    if not os.path.exists(directory):
        return None
    
    for file in os.listdir(directory):
        if Path(file).suffix.lower() in VIDEO_EXTENSIONS:
            return os.path.join(directory, file)
    return None

def main():
    """Main processing function"""
    print("Starting video processing pipeline...")
    
    # Step 1: Setup and copy all files from src
    setup_directories()
    copied_files = copy_all_files()
    
    if not copied_files:
        print("No files to process. Exiting.")
        return
    
    # Step 2: Extract nested zip files recursively
    extract_nested_zips()
    
    # Step 3: Get all video files
    video_files = get_video_files()
    
    if not video_files:
        print("No video files found after extraction. Exiting.")
        return
    
    print(f"Found {len(video_files)} video files")
    
    # Step 4: Normalize and encode videos to H.265 (single pass)
    normalized_files = []
    temp_dir = os.path.join(UNZIPPED_DIR, "normalized")
    os.makedirs(temp_dir, exist_ok=True)
    
    print(f"Normalizing and encoding videos to H.265... (this may take a while)")
    for i, video_file in enumerate(video_files):
        print(f"Processing video {i+1}/{len(video_files)}: {os.path.basename(video_file)}")
        normalized_path = os.path.join(temp_dir, f"normalized_{i:03d}.mp4")
        if normalize_and_encode_video(video_file, normalized_path):
            normalized_files.append(normalized_path)
    
    if not normalized_files:
        print("No videos were successfully normalized. Exiting.")
        return
    
    # Step 5: Concatenate main videos (no re-encoding)
    temp_inner = os.path.join(temp_dir, "temp_inner.mp4")
    if not concatenate_videos(normalized_files, temp_inner):
        print("Failed to concatenate main videos. Exiting.")
        return
    
    # Step 6: Handle start and end videos
    start_video = find_video_in_directory(START_DIR)
    end_video = find_video_in_directory(END_DIR)
    
    final_sequence = []
    
    # Add start video if exists
    if start_video:
        start_normalized = os.path.join(temp_dir, "start_normalized.mp4")
        if normalize_and_encode_video(start_video, start_normalized):
            final_sequence.append(start_normalized)
            print(f"Added start video: {start_video}")
    
    # Add main content
    final_sequence.append(temp_inner)
    
    # Add end video if exists
    if end_video:
        end_normalized = os.path.join(temp_dir, "end_normalized.mp4")
        if normalize_and_encode_video(end_video, end_normalized):
            final_sequence.append(end_normalized)
            print(f"Added end video: {end_video}")
    
    # Step 7: Create final concatenated file (no re-encoding needed)
    if not concatenate_videos(final_sequence, OUTPUT_FILE):
        print("Failed to create final concatenated video. Exiting.")
        return
    
    print(f"✅ Processing complete! Final H.265 video: {OUTPUT_FILE}")
    
    # Show file size
    try:
        final_size = os.path.getsize(OUTPUT_FILE) / (1024*1024)  # MB
        print(f"📊 Final file size: {final_size:.1f} MB")
    except:
        pass
    
    # Clean up temporary files
    try:
        shutil.rmtree(temp_dir)
        print("Cleaned up temporary files")
    except Exception as e:
        print(f"Warning: Could not clean up temp directory: {e}")

if __name__ == "__main__":
    main()
